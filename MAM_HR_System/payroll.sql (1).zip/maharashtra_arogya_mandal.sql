-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 08, 2013 at 09:06 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `maharashtra_arogya_mandal`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE IF NOT EXISTS `attendance` (
  `employee_no` int(10) NOT NULL DEFAULT '0',
  `month_no` varchar(10) NOT NULL DEFAULT '0',
  `pay_days` int(10) DEFAULT NULL,
  `adj_days` int(10) DEFAULT NULL,
  `ot_hrs` int(10) DEFAULT NULL,
  `leave_encash_days` int(10) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `created_by` varchar(10) DEFAULT NULL,
  `updated_on` date DEFAULT NULL,
  `updated_by` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`employee_no`,`month_no`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`employee_no`, `month_no`, `pay_days`, `adj_days`, `ot_hrs`, `leave_encash_days`, `created_on`, `created_by`, `updated_on`, `updated_by`) VALUES
(18, '2013-01', 25, 1, 0, 0, '0000-00-00', '', '2013-01-21', 'admin'),
(17, '2013-01', 25, 1, 0, 0, '0000-00-00', '', '2013-01-21', 'admin'),
(16, '2013-01', 25, 0, 0, 0, '0000-00-00', '', '2013-01-21', 'admin'),
(15, '2013-01', 25, 0, 0, 0, '0000-00-00', '', '2013-01-21', 'admin'),
(1, '2013-01', 25, 0, 0, 0, '0000-00-00', '', '2013-01-21', 'admin'),
(14, '2013-01', 25, 0, 0, 0, '0000-00-00', '', '2013-01-21', 'admin'),
(13, '2013-01', 25, 0, 0, 0, '0000-00-00', '', '2013-01-21', 'admin'),
(12, '2013-01', 25, 0, 0, 0, '0000-00-00', '', '2013-01-21', 'admin'),
(11, '2013-01', 25, 0, 0, 0, '0000-00-00', '', '2013-01-21', 'admin'),
(10, '2013-01', 25, 0, 0, 0, '0000-00-00', '', '2013-01-21', 'admin'),
(9, '2013-01', 25, 0, 0, 0, '0000-00-00', '', '2013-01-21', 'admin'),
(8, '2013-01', 25, 0, 0, 0, '0000-00-00', '', '2013-01-21', 'admin'),
(7, '2013-01', 25, 0, 0, 0, '0000-00-00', '', '2013-01-21', 'admin'),
(6, '2013-01', 25, 0, 0, 0, '0000-00-00', '', '2013-01-21', 'admin'),
(5, '2013-01', 25, 0, 0, 0, '0000-00-00', '', '2013-01-21', 'admin'),
(4, '2013-01', 25, 0, 0, 0, '0000-00-00', '', '2013-01-21', 'admin'),
(3, '2013-01', 25, 0, 0, 0, '0000-00-00', '', '2013-01-21', 'admin'),
(2, '2013-01', 25, 0, 0, 0, '0000-00-00', '', '2013-01-21', 'admin'),
(1, '', 25, 0, 0, 0, '0000-00-00', '', '2013-01-21', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `batch_dtls`
--

CREATE TABLE IF NOT EXISTS `batch_dtls` (
  `batch_no` varchar(20) NOT NULL,
  `employee_no` varchar(20) NOT NULL,
  `comp_code` varchar(20) NOT NULL,
  `adj_amount` float NOT NULL,
  `remark_for_adj` varchar(200) NOT NULL,
  `created_on` date NOT NULL,
  `created_by` varchar(20) NOT NULL,
  `updated_on` date NOT NULL,
  `updated_by` varchar(20) NOT NULL,
  PRIMARY KEY (`batch_no`,`employee_no`,`comp_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `batch_dtls`
--

INSERT INTO `batch_dtls` (`batch_no`, `employee_no`, `comp_code`, `adj_amount`, `remark_for_adj`, `created_on`, `created_by`, `updated_on`, `updated_by`) VALUES
('B1', '1', 'F0003', 3000, '', '2013-01-21', 'admin', '0000-00-00', ''),
('B1', '1', 'F0001', 2000, '', '2013-01-21', 'admin', '0000-00-00', ''),
('B1', '1', 'F0002', 3000, '', '2013-01-21', 'admin', '0000-00-00', ''),
('B2', '7', 'F0002', 1000, '', '2013-01-23', 'admin', '0000-00-00', ''),
('B2', '11', 'F0003', 2000, '', '2013-01-23', 'admin', '0000-00-00', '');

-- --------------------------------------------------------

--
-- Table structure for table `batch_hdr`
--

CREATE TABLE IF NOT EXISTS `batch_hdr` (
  `batch_no` varchar(20) NOT NULL,
  `month_no` varchar(20) NOT NULL,
  `remark` varchar(200) NOT NULL,
  `created_on` date NOT NULL,
  `created_by` varchar(20) NOT NULL,
  `updated_on` date NOT NULL,
  `updated_by` varchar(20) NOT NULL,
  PRIMARY KEY (`batch_no`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `batch_hdr`
--

INSERT INTO `batch_hdr` (`batch_no`, `month_no`, `remark`, `created_on`, `created_by`, `updated_on`, `updated_by`) VALUES
('B2', '2013-01', '', '2013-01-23', 'admin', '0000-00-00', ''),
('B1', '2013-01', 'Batch B1', '2013-01-21', 'admin', '2013-01-22', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `comp_head`
--

CREATE TABLE IF NOT EXISTS `comp_head` (
  `comp_code` varchar(15) NOT NULL DEFAULT '',
  `comp_name` varchar(30) DEFAULT NULL,
  `code_descr` varchar(50) DEFAULT NULL,
  `pay_when` varchar(1) DEFAULT NULL,
  `pf_compute` varchar(1) DEFAULT NULL,
  `pt_compute` varchar(1) DEFAULT NULL,
  `esi_compute` varchar(1) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `created_by` varchar(10) DEFAULT NULL,
  `updated_on` date DEFAULT NULL,
  `updated_by` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`comp_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comp_head`
--

INSERT INTO `comp_head` (`comp_code`, `comp_name`, `code_descr`, `pay_when`, `pf_compute`, `pt_compute`, `esi_compute`, `created_on`, `created_by`, `updated_on`, `updated_by`) VALUES
('E0009', 'Earning 9', '', 'A', 'Y', 'Y', 'Y', '0000-00-00', 'admin', '0000-00-00', ''),
('E0008', 'Earning 8', '', 'P', 'Y', 'Y', 'Y', '0000-00-00', 'admin', '0000-00-00', ''),
('E0007', 'Earning 7', '', 'P', 'Y', 'Y', 'Y', '0000-00-00', 'admin', '0000-00-00', ''),
('E0006', 'Earning 6', '', 'P', 'Y', 'Y', 'Y', '0000-00-00', 'admin', '0000-00-00', ''),
('E0005', 'Earning 5', '', 'P', 'Y', 'Y', 'Y', '0000-00-00', 'admin', '0000-00-00', ''),
('E0004', 'Earning 4', '', 'P', 'Y', 'Y', 'Y', '0000-00-00', 'admin', '0000-00-00', ''),
('E0003', 'Earning 3', '', 'P', 'Y', 'Y', 'Y', '0000-00-00', 'admin', '0000-00-00', ''),
('E0002', 'Earning 2', 'Earning 2', 'P', 'Y', 'Y', 'Y', '0000-00-00', 'admin', '0000-00-00', ''),
('E0001', 'Earning 1', 'Earning 1', 'P', 'Y', 'Y', 'Y', '0000-00-00', 'admin', '0000-00-00', 'admin'),
('E0010', 'Earning 10', '', 'P', 'Y', 'Y', 'Y', '0000-00-00', 'admin', '0000-00-00', ''),
('D0001', 'Provident Fund', '', 'P', 'N', 'N', 'N', '0000-00-00', 'admin', '0000-00-00', ''),
('D0002', 'Profession Tax', '', 'P', 'N', 'N', 'N', '0000-00-00', 'admin', '0000-00-00', ''),
('D0003', 'ESI', '', 'P', 'N', 'N', 'N', '0000-00-00', 'admin', '0000-00-00', ''),
('D0004', 'Deduction 1', '', 'P', 'N', 'N', 'N', '0000-00-00', 'admin', '0000-00-00', ''),
('F0001', 'LTA', '', 'A', 'N', 'N', 'N', '0000-00-00', 'admin', '0000-00-00', ''),
('F0002', 'Fixed 1', '', 'X', 'N', 'N', 'N', '0000-00-00', 'admin', '0000-00-00', 'admin'),
('X0001', 'Medical Bills', '', 'X', 'N', 'N', 'N', '0000-00-00', 'admin', '0000-00-00', ''),
('X0002', 'X 1', '', 'X', 'N', 'N', 'N', '0000-00-00', 'admin', '0000-00-00', ''),
('E0011', '1', '', 'P', 'Y', 'Y', 'Y', '0000-00-00', 'admin', '0000-00-00', ''),
('E0012', 'Code name', 'Test Remark ', 'A', 'Y', 'Y', 'Y', '0000-00-00', 'admin', '0000-00-00', ''),
('F0003', 'Fixed 3', '', 'A', 'N', 'N', 'N', '0000-00-00', 'admin', '0000-00-00', ''),
('E0013', 'House Rent Allowance', '', 'P', 'Y', 'Y', 'Y', '0000-00-00', 'admin', '0000-00-00', ''),
('E0014', 'f', 'f', 'A', 'N', 'N', 'N', '0000-00-00', 'admin', '0000-00-00', '');

-- --------------------------------------------------------

--
-- Table structure for table `empl_comp_log`
--

CREATE TABLE IF NOT EXISTS `empl_comp_log` (
  `employee_no` varchar(20) NOT NULL,
  `comp_code` varchar(20) NOT NULL,
  `transaction_date` date NOT NULL,
  `old_amount` float NOT NULL,
  `new_amount` float NOT NULL,
  PRIMARY KEY (`employee_no`,`comp_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `empl_comp_log`
--


-- --------------------------------------------------------

--
-- Table structure for table `emp_comp_master`
--

CREATE TABLE IF NOT EXISTS `emp_comp_master` (
  `employee_no` varchar(10) NOT NULL DEFAULT '',
  `created_on` date DEFAULT NULL,
  `created_by` varchar(10) DEFAULT NULL,
  `updated_on` date DEFAULT NULL,
  `updated_by` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`employee_no`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_comp_master`
--

INSERT INTO `emp_comp_master` (`employee_no`, `created_on`, `created_by`, `updated_on`, `updated_by`) VALUES
('1', '2013-01-21', 'admin', '0000-00-00', '');

-- --------------------------------------------------------

--
-- Table structure for table `emp_comp_master_lines`
--

CREATE TABLE IF NOT EXISTS `emp_comp_master_lines` (
  `employee_no` varchar(20) NOT NULL,
  `comp_code` varchar(20) NOT NULL,
  `comp_change_eff_date` date NOT NULL,
  `amount` float NOT NULL,
  PRIMARY KEY (`employee_no`,`comp_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_comp_master_lines`
--

INSERT INTO `emp_comp_master_lines` (`employee_no`, `comp_code`, `comp_change_eff_date`, `amount`) VALUES
('1', 'E0008', '0000-00-00', 5000),
('1', 'E0007', '0000-00-00', 10000),
('1', 'E0006', '0000-00-00', 2000),
('1', 'E0005', '0000-00-00', 10000),
('1', 'E0004', '0000-00-00', 5000),
('1', 'E0003', '0000-00-00', 3000),
('1', 'E0002', '0000-00-00', 4000),
('1', 'E0001', '0000-00-00', 5000),
('1', 'D0004', '0000-00-00', 1000),
('1', 'D0003', '0000-00-00', 0),
('1', 'D0002', '0000-00-00', 0),
('1', 'D0001', '0000-00-00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `grade_comp_master`
--

CREATE TABLE IF NOT EXISTS `grade_comp_master` (
  `grade` varchar(50) NOT NULL DEFAULT '',
  `comp_code` varchar(5) NOT NULL DEFAULT '',
  `amount` int(10) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `created_by` varchar(10) DEFAULT NULL,
  `updated_on` date DEFAULT NULL,
  `updated_by` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`grade`,`comp_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grade_comp_master`
--

INSERT INTO `grade_comp_master` (`grade`, `comp_code`, `amount`, `created_on`, `created_by`, `updated_on`, `updated_by`) VALUES
('A', 'E0003', 3000, '2013-01-21', 'admin', '2013-01-21', 'admin'),
('A', 'E0002', 4000, '2013-01-21', 'admin', '2013-01-21', 'admin'),
('A', 'E0001', 5000, '2013-01-21', 'admin', '2013-01-21', 'admin'),
('A', 'E0004', 5000, '2013-01-21', 'admin', '2013-01-21', 'admin'),
('A', 'E0005', 10000, '2013-01-21', 'admin', '2013-01-21', 'admin'),
('A', 'E0006', 2000, '2013-01-21', 'admin', '2013-01-21', 'admin'),
('A', 'E0007', 10000, '2013-01-21', 'admin', '2013-01-21', 'admin'),
('A', 'E0008', 5000, '2013-01-21', 'admin', '2013-01-21', 'admin'),
('A', 'D0001', 0, '2013-01-21', 'admin', '2013-01-21', 'admin'),
('A', 'D0002', 0, '2013-01-21', 'admin', '2013-01-21', 'admin'),
('A', 'D0003', 0, '2013-01-21', 'admin', '2013-01-21', 'admin'),
('A', 'D0004', 1000, '2013-01-21', 'admin', '2013-01-21', 'admin'),
('B', 'D0003', 100, '2013-01-23', 'admin', '0000-00-00', '');

-- --------------------------------------------------------

--
-- Table structure for table `grade_master`
--

CREATE TABLE IF NOT EXISTS `grade_master` (
  `grade` varchar(10) NOT NULL,
  `desc` varchar(100) NOT NULL,
  PRIMARY KEY (`grade`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grade_master`
--

INSERT INTO `grade_master` (`grade`, `desc`) VALUES
('B', 'Grade B'),
('A', 'Grade A');

-- --------------------------------------------------------

--
-- Table structure for table `month_control`
--

CREATE TABLE IF NOT EXISTS `month_control` (
  `month_no` varchar(10) NOT NULL DEFAULT '0',
  `month_active` varchar(1) DEFAULT NULL,
  `no_days` int(10) DEFAULT NULL,
  `per_day_divisor` int(10) DEFAULT NULL,
  `da_index` int(10) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `created_by` varchar(10) DEFAULT NULL,
  `updated_on` date DEFAULT NULL,
  `updated_by` varchar(10) DEFAULT NULL,
  `process_status` varchar(10) NOT NULL,
  PRIMARY KEY (`month_no`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `month_control`
--

INSERT INTO `month_control` (`month_no`, `month_active`, `no_days`, `per_day_divisor`, `da_index`, `created_on`, `created_by`, `updated_on`, `updated_by`, `process_status`) VALUES
('2012-12', 'N', 31, 25, 0, '0000-00-00', 'admin', '0000-00-00', '', '0'),
('2013-02', 'N', 28, 20, 0, '0000-00-00', 'admin', '0000-00-00', '', '0'),
('2013-01', 'Y', 31, 25, 0, '0000-00-00', 'admin', '0000-00-00', '', 'Complete'),
('2013-03', 'N', 31, 25, 0, '0000-00-00', 'admin', '0000-00-00', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `payroll_details`
--

CREATE TABLE IF NOT EXISTS `payroll_details` (
  `employee_no` varchar(20) NOT NULL,
  `month_no` varchar(20) NOT NULL,
  `comp_code` varchar(20) NOT NULL,
  `eligible_amt` float NOT NULL,
  `computed_amt` float NOT NULL,
  `adj_amt` float NOT NULL,
  `paid_amt` float NOT NULL,
  `created_on` varchar(20) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `updated_on` varchar(20) NOT NULL,
  `updated_by` varchar(50) NOT NULL,
  PRIMARY KEY (`employee_no`,`month_no`,`comp_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payroll_details`
--

INSERT INTO `payroll_details` (`employee_no`, `month_no`, `comp_code`, `eligible_amt`, `computed_amt`, `adj_amt`, `paid_amt`, `created_on`, `created_by`, `updated_on`, `updated_by`) VALUES
('2', '2013-01', 'D0002', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('2', '2013-01', 'D0001', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('3', '2013-01', 'D0003', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('3', '2013-01', 'D0002', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('3', '2013-01', 'D0001', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('4', '2013-01', 'D0003', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('4', '2013-01', 'D0002', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('4', '2013-01', 'D0001', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('5', '2013-01', 'D0003', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('5', '2013-01', 'D0002', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('5', '2013-01', 'D0001', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('6', '2013-01', 'D0003', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('6', '2013-01', 'D0002', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('6', '2013-01', 'D0001', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('7', '2013-01', 'D0003', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('7', '2013-01', 'D0002', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('7', '2013-01', 'D0001', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('7', '2013-01', 'F0002', 0, 0, 0, 1000, '2013/01/30', 'admin', '', ''),
('8', '2013-01', 'D0003', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('8', '2013-01', 'D0002', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('8', '2013-01', 'D0001', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('9', '2013-01', 'D0003', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('9', '2013-01', 'D0002', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('9', '2013-01', 'D0001', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('10', '2013-01', 'D0003', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('10', '2013-01', 'D0002', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('10', '2013-01', 'D0001', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('11', '2013-01', 'D0003', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('11', '2013-01', 'D0002', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('11', '2013-01', 'D0001', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('11', '2013-01', 'F0003', 0, 0, 0, 2000, '2013/01/30', 'admin', '', ''),
('12', '2013-01', 'D0003', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('12', '2013-01', 'D0002', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('12', '2013-01', 'D0001', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('13', '2013-01', 'D0003', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('13', '2013-01', 'D0002', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('13', '2013-01', 'D0001', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('14', '2013-01', 'D0003', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('14', '2013-01', 'D0002', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('14', '2013-01', 'D0001', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('1', '2013-01', 'F0002', 0, 0, 0, -7000, '2013/01/30', 'admin', '', ''),
('1', '2013-01', 'F0003', 0, 0, 0, 3000, '2013/01/30', 'admin', '', ''),
('1', '2013-01', 'F0001', 0, 0, 0, 2000, '2013/01/30', 'admin', '', ''),
('1', '2013-01', 'D0004', 1000, 806.452, 0, 806.452, '2013/01/30', 'admin', '', ''),
('1', '2013-01', 'D0003', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('1', '2013-01', 'D0002', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('1', '2013-01', 'D0001', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('1', '2013-01', 'E0008', 5000, 4032.26, 0, 4032.26, '2013/01/30', 'admin', '', ''),
('1', '2013-01', 'E0007', 10000, 8064.52, 0, 8064.52, '2013/01/30', 'admin', '', ''),
('1', '2013-01', 'E0006', 2000, 1612.9, 0, 1612.9, '2013/01/30', 'admin', '', ''),
('1', '2013-01', 'E0004', 5000, 4032.26, 0, 4032.26, '2013/01/30', 'admin', '', ''),
('1', '2013-01', 'E0005', 10000, 8064.52, 0, 8064.52, '2013/01/30', 'admin', '', ''),
('1', '2013-01', 'E0003', 3000, 2419.35, 0, 2419.35, '2013/01/30', 'admin', '', ''),
('1', '2013-01', 'E0001', 5000, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('15', '2013-01', 'D0003', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('15', '2013-01', 'D0002', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('15', '2013-01', 'D0001', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('16', '2013-01', 'D0003', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('16', '2013-01', 'D0002', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('16', '2013-01', 'D0001', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('17', '2013-01', 'D0003', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('17', '2013-01', 'D0002', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('17', '2013-01', 'D0001', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('18', '2013-01', 'D0003', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('18', '2013-01', 'D0002', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('18', '2013-01', 'D0001', 0, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('2', '2013-01', 'D0003', 0, 0, 0, 0, '2013/01/30', 'admin', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `payroll_hdr`
--

CREATE TABLE IF NOT EXISTS `payroll_hdr` (
  `employee_no` varchar(20) NOT NULL,
  `month_no` varchar(20) NOT NULL,
  `grade` varchar(10) NOT NULL,
  `bank_branch_name` varchar(100) NOT NULL,
  `bank_account_no` varchar(20) NOT NULL,
  `pay_days` int(11) NOT NULL,
  `gross_earnings` float NOT NULL,
  `gross_deduction` float NOT NULL,
  `net_salary` float NOT NULL,
  `created_on` varchar(20) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `updated_on` varchar(20) NOT NULL,
  `updated_by` varchar(50) NOT NULL,
  PRIMARY KEY (`employee_no`,`month_no`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payroll_hdr`
--

INSERT INTO `payroll_hdr` (`employee_no`, `month_no`, `grade`, `bank_branch_name`, `bank_account_no`, `pay_days`, `gross_earnings`, `gross_deduction`, `net_salary`, `created_on`, `created_by`, `updated_on`, `updated_by`) VALUES
('3', '2013-01', '', '', '', 25, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('4', '2013-01', '', '', '', 25, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('5', '2013-01', '', '', '', 25, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('6', '2013-01', '', '', '', 25, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('8', '2013-01', '', '', '', 25, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('7', '2013-01', '', '', '', 25, 1000, 0, 1000, '2013/01/30', 'admin', '', ''),
('9', '2013-01', '', '', '', 25, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('10', '2013-01', '', '', '', 25, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('12', '2013-01', '', '', '', 25, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('11', '2013-01', '', '', '', 25, 2000, 0, 2000, '2013/01/30', 'admin', '', ''),
('13', '2013-01', '', '', '', 25, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('14', '2013-01', '', '', '', 25, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('1', '2013-01', '', '', '', 25, 36226, 25206, 11020, '2013/01/30', 'admin', '', ''),
('16', '2013-01', '', '', '', 25, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('18', '2013-01', '', '', '', 25, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('15', '2013-01', '', '', '', 25, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('17', '2013-01', '', '', '', 25, 0, 0, 0, '2013/01/30', 'admin', '', ''),
('2', '2013-01', '', '', '', 25, 0, 0, 0, '2013/01/30', 'admin', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `recovery`
--

CREATE TABLE IF NOT EXISTS `recovery` (
  `employee_no` varchar(10) NOT NULL DEFAULT '',
  `recov_title` varchar(20) NOT NULL DEFAULT '',
  `total_amount` int(10) DEFAULT NULL,
  `no_of_installments` int(10) DEFAULT NULL,
  `inst_amount` int(10) DEFAULT NULL,
  `balance_amount` int(10) DEFAULT NULL,
  `comp_code` varchar(5) DEFAULT NULL,
  `recov_status` varchar(10) DEFAULT NULL,
  `remarks` varchar(50) DEFAULT NULL,
  `count` int(11) NOT NULL,
  `created_on` date DEFAULT NULL,
  `created_by` varchar(10) DEFAULT NULL,
  `updated_on` date DEFAULT NULL,
  `updated_by` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`employee_no`,`recov_title`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recovery`
--

INSERT INTO `recovery` (`employee_no`, `recov_title`, `total_amount`, `no_of_installments`, `inst_amount`, `balance_amount`, `comp_code`, `recov_status`, `remarks`, `count`, `created_on`, `created_by`, `updated_on`, `updated_by`) VALUES
('1', 'X0002', 10000, 2, 5000, 5000, 'F0002', 'Close', 'Remark For Recovery X0002', 2, '2013-01-23', 'admin', '0000-00-00', ''),
('1', 'X0001', 10000, 2, 5000, 10000, 'F0002', 'Open', 'Remark For Recovery', 1, '2013-01-21', 'admin', '2013-01-21', 'admin');
